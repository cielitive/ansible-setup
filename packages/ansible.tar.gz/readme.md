### Download
$ pip download -d ./ansible-2.9.23 ansible==2.9.23
$ pip download -d ./ansible_lint-5.3.2 ansible-lint==5.3.2

$ tar zcvf ansible-2.9.23 ansible_lint-5.3.2 readme.md

### Install
$ tar zxvf ansible.tar.gz

$ pip3 install --no-index --find-links=./ansible-2.9.23 ansible
$ pip3 install --no-index --find-links=./ansible_lint-5.3.2 ansible-lint

$ pip3 freeze | egrep "^ansible=="
ansible==2.9.23
$ ansible --version
ansible 2.9.23
  config file = None
  configured module search path = ['/root/.ansible/plugins/modules', '/usr/share/ansible/plugins/modules']
  ansible python module location = /usr/local/lib/python3.6/site-packages/ansible
  executable location = /usr/local/bin/ansible
  python version = 3.6.8 (default, Sep 10 2021, 09:13:53) [GCC 8.5.0 20210514 (Red Hat 8.5.0-3)]

$ pip3 freeze | egrep "^ansible-lint=="
ansible-lint==5.3.2
$ ansible-lint --version
ansible-lint 5.3.2 using ansible 2.9.23

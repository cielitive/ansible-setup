### Linux Kernel Parameter Tuning

####

```bash
### ip_conntrack(iptablesでパケットを追跡するためにパケットの情報を記録するファイル)に記録できる上限数
net.nf_conntrack_max:
### IPv4リバースパスフィルタリングの有効・無効化(スプーフィング(送信元IP偽装)対策)
net.ipv4.conf.all.rp_filter: 1
net.ipv4.conf.default.rp_filter: 0
```

```bash
### Docker, LXC/LXD
### ユーザーIDごとに作成可能なinotifyインスタンスの最大数
fs.inotify.max_user_instances:
### inotifyインスタンスについてキューに入れられるイベントの最大数
fs.inotify.max_queued_events:
### ユーザーIDごとに作成可能なwatch(inotifyインスタンスによって監視される単一のファイル)の最大数
fs.inotify.max_user_watches:
```

#### Process

```bash
### システム全体でカーネルが一度に使用できるスレッドの最大数
kernel.threads-max:
### プロセス番号の最大値
kernel.pid_max:
### プロセスが使用可能なメモリマップ領域の最大数
vm.max_map_count:
```

```bash
### プロセス間メッセージの最大サイズ
kernel.msgmax:
### 1つのメッセージキューに書き込み可能な最大サイズ
kernel.msgmnb:
### システム全体のメッセージキュー数の最大値
kernel.msgmni:
```

```bash
### セマフォの最大数
kernel.sem:
```

#### File Descriptor

```bash
### システム全体でのファイルハンドル(ファイルディスクリプタ)の最大数
fs.file-max:
### ファイルディスクリプタの使用状況 (現在までの最大値, 現在の値, 上限値)
fs.file-nr:
### すべてのアクティブな非同期I/Oコンテキスト内で許可されるイベントの最大数
fs.aio-max-nr:
```

```bash
### プロセスが保有できるファイルの最大数ソケット含む)
$ ulimit -a
open files                      (-n) 1024

$ ulimit -SHn 65535
```

#### Memory

```bash
### 一度にシステムで使用できる共有メモリーページの合計量 (page)
kernel.shmall:
### カーネルで許容される1共有メモリーセグメントの最大サイズ
kernel.shmmax:
### システム全体の共有メモリーセグメントの最大数
kernel.shmmni:
```

#### Network

```bash
### TIME_OUT状態のコネクションを再利用
net.ipv4.tcp_tw_reuse: 0
### TCPのタイムスタンプ付与機能を有効・無効化
net.ipv4.tcp_timestamps: 1
### TCPのウィンドウサイズの上限を拡張する機能の有効・無効化
net.ipv4.tcp_window_scaling: 1
### TCPパラメータのSACKオプションの有効・無効化
net.ipv4.tcp_sack: 1
```

```bash
### カーネルの処理可能速度よりも高速にパケットを受信した場合に処理待ちキューに入れることができるパケットの最大数
net.core.netdev_max_backlog: 1000
```

```bash
### TCPソケットが受け付けた接続要求を格納するキューの最大数 (ESTABLISHED状態のソケット)
net.core.somaxconn: 128
### TCPソケット当たりのSYNを受け付けてACKを受け取っていない状態のコネクションの保持可能数 (SYN_RECEIVED状態のソケット)
net.ipv4.tcp_max_syn_backlog: 128
### SYN cookies機能の有効・無効化 (->syn_backlog(一時情報)をSYN+ACKとともに送信する)
net.ipv4.tcp_syncookies: 1
```

```bash
### 新しい接続を開始するときカーネルがSYNパケットをリトライする回数
net.ipv4.tcp_syn_retries: 6
### 接続を受付側としてオープンするときSYN+ACKパケットをリトライする回数
net.ipv4.tcp_synack_retries: 5
```

```bash
### コネクション作成時におけるローカルポート番号の範囲
net.ipv4.ip_local_port_range: 32768	60999
```

```bash
### TCPコネクション開始からKeepAliveメッセージの送信を開始するまでの時間
net.ipv4.tcp_keepalive_time: 7200
### KeepAlive送信開始後の再送間隔
net.ipv4.tcp_keepalive_intvl: 75
### TCPコネクション切断までのKeepAlive失敗回数
net.ipv4.tcp_keepalive_probes: 9
```

```bash
###
net.ipv4.tcp_fin_timeout:
```

```bash
### どのユーザファイルハンドルにもアタッチしていないTCPソケットを保有できる最大数
net.ipv4.tcp_max_orphans:
```

```bash
### ※アプリケーションがソケットオプションでソケットバッファサイズを指定しない場合はデフォルト（_default）の値が使用される
### ソケットが使用する送信バッファーのデフォルトのサイズ
net.core.wmem_default:
### ソケットが使用する受信バッファーのデフォルトのサイズ
net.core.rmem_default:
### ソケットが使用する送信バッファーの最大サイズ
net.core.wmem_max:
### ソケットが使用する受信バッファーの最大サイズ
net.core.rmem_max:
```

```bash
### ソケットバッファのサイズ (min / default / max)
net.ipv4.tcp_mem:
### ※初期値は、デフォルト（_default）より優先される
### 送信ソケットバッファのサイズ (min / default / max)
net.ipv4.tcp_wmem:
### 受信ソケットバッファのサイズ (min / default / max)
net.ipv4.tcp_rmem:
```

```bash
### カーネルがTCP用に使用できるメモリサイズ (page, 1page=4,096byte)
net.ipv4.tcp_mem:
```

#### Disk

```bash
### バックグラウンドでライトバックを行うキャッシュサイズの閾値 (物理メモリに占める割合(%))
vm.dirty_background_ratio:
### フォアグラウンドでライトバックを行うキャッシュサイズの閾値 (物理メモリに占める割合(%))
vm.dirty_ratio:
### ライトバックされるまでのキャッシュの保持期間
vm.dirty_expire_centisecs:
### キャッシュの経過時間を監視する間隔
vm.dirty_writeback_centisecs:
```
